numero = int(input('Digite um número: '))

multiplicador = 1

while(multiplicador < 3000):
    resultado = multiplicador * multiplicador
    print(f'{numero} x {multiplicador} = {resultado}') 
    multiplicador = multiplicador +1   