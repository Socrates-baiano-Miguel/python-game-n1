#n = ['Miguel','Socrates','Baiano']
#for nome in n: 
    #print(nome)
    
    
#soma = 0
#for i in range(1,12001):
    #soma = soma +5
    #print(soma)
    
    
n = 30
fat = 1
for i in range (1, n*1):
    fat = fat * i
    print(f"fatorial de {n} é {fat}")    
    