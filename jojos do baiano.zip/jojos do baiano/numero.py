print('digite um numero')

num = int(input('Coloque Um Numero: '))

if num > 0 :
 print('seu numero é positivo')
 
elif num == 0 :
    print('seu numero é 0')
    
else :
    print('seu numero é negativo')