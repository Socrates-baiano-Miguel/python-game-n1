//const numbers = [6,7,4,3,7,9]
//const flt = numbers.filter(n => n%3 === 0)
//console.log(flt)

//const sm = [300,800,500,766,666,999].reduce
//((acumulador, valoratual)=> acumulador + valoratual);
//console.log(sm)

//let repeat = [6,6,6,9,0,7,4,4,7,9];
//let fz = [... new Set(repeat)]
//console.log(fz)

let repeat = ['leo','leo','rafa','rafa','baiano','baiano']
let fz = [... new Set(repeat)]
console.log(fz)
