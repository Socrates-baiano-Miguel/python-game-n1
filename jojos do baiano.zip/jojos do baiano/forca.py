print("**********************************************************")
print("BEM VINDO MEU NOBRE AO JOGO DA FORCA NESSA BAGAÇA")
print("**********************************************************")

print("END GAME")