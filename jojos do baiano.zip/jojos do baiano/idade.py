print('********************')
print('Verifique sua idade')
print('********************')

idade = int(input('Digite Sua Idade'))

if(idade >= 18 ):
    print('Você É Maior De Idade')
    
elif(idade == 18):
    print('Você É Adolecente')   
    
else:
    print('Você É menor') 