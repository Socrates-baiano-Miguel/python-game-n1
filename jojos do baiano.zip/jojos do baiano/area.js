let base = 20;
let altura = 30;

area = base*altura;

if(base == altura){
    console.log('E um Quadrado');
} else {
    console.log('É um retângulo');
}
