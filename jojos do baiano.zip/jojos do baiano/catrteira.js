let y = 25;
let = pCDM = true;

if(y > 18 && pCDM){
    console.log ('Pode Dirigir');
} else {console.log ('Não Pode Dirigir');
}