let saborSelecionado = 'abacaxi'

if(saborSelecionado == 'abacaxi')
{console.log('está fora de estoque');}

else if(saborSelecionado == 'uva')
{console.log('está fora de estoque');}

else if(saborSelecionado == 'banana')
{console.log('está fora de estoque');}

else {console.log('temos esses sabores');}