//guardando informações pessoais dos clientes
const pessoalInfo = ["Nome", "Miguel", "Idade", 18, "CPF", "989804937294873" ]

console.log(pessoalInfo)

let objectpessoal = {
    nome: "Miguel",
    idade: 18,
    cpf: "989804937294873",
    email: "migs@example.com",

}
console.log(objectpessoal)