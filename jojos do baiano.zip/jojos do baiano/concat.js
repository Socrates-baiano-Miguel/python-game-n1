let tP  = ['Heloa', 'Maria-Rafaela', 'Maria-Eduarda', 'Diego', 'João-Victor', 'Gabriel', 'Luana', 'Thauanne', 'Aline', 'Lucas'];
let tSI = ['Leonardo', 'Miguel', 'João-Paulo', 'Rafael'];

tSI.pop();
tP.push('Rafael');

console.log('Time de Progamação Back-End', tP);
console.log('************************************************************************');
console.log('Time de Segurança da Informação', tSI);


let funci = tP.concat(tSI);
console.log(funci);

let jpdemitido = funci.splice()
