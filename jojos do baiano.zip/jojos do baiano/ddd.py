import random

numeR = int(random.random()*100)

print(numeR)