let nome = ""
let email = "migs@example.com";

let nomeV = nome / "Nome Não Fornecido";

let emaiV = email / "Email Não Fornecido";

console.log ("nome: ",nomeV);

console.log ("email: ",emaiV);