let idade = 18
let CBrasileira = true;

if(idade >= 18 && CBrasileira == true) {
    console.log ('Voçê Pode Votar');
} else {console.log ('Voçê Não Pode Votar');}


