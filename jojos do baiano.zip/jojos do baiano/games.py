import jogogoa 
import forca
print("****************************")
print("Meu Nobre Escolha o Seu Game")
print("****************************")

print("(1)Forca (2)Jogo Da Adivinhação")

game = int(input("Qual Jogo?: "))

if(game == 1):
    print("Meu nobre é o JOGO DA FORCA!")
    forca.start_forca()
else:
    print("É a ADIVINHAÇÃO MASTER meu nobre")
    jogogoa.start_AMaster()