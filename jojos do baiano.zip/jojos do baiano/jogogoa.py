print ('*********************************')
print ('Bem Vindo Ao Jogo De Adivinnhação')
print ('*********************************')

#definindo o numero secreto
numeroS = 29

#numero de tentativas
nT = 3
while(nT >0):
    nT = nT -1

    chute = int(input('Digite Um número: '))

#declarando as condições
    if numeroS == chute: 
        print('Tu é Foda')
    elif(chute>numeroS):
        print('BATEU NA TRRRRRRAVE!!!!!!! É um Numero Menor')
    else:
        print('Tu é Mt Ruim Meu Nobre É Maior')   
   
