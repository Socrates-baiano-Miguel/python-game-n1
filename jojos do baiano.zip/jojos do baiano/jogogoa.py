print ('*********************************')
print ('Bem Vindo Ao Jogo De Adivinnhação')
print ('*********************************')

numeroS = 29

chuteTxt = input('Determine Um Número')

print('Você digitou o número', chuteTxt )

chute = int(chuteTxt)

if numeroS == chute: 
    
    print('Tu é Foda')

elif(chute>numeroS):
    
    print('BATEU NA TRRRRRRAVE!!!!!!! É um Numero Menor')

else:
    
    print('Tu é Mt Ruim Meu Nobre É Maior')
