contador = 5
 
while(contador >0):
    print('contador')  
    contador = contador -1
    
print('Fim')